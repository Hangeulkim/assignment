#define NAME_SIZE 64 //이름 최대 길이 선언

struct ssu_employee{//employee 구조체
    char name[NAME_SIZE];//이름 변수
    int pid;//아이디
    int salary;//연봉
};
