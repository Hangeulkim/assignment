#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(void)
{
    while (1) {//무한 루프를 돌게만듬
        printf("\n[OSLAB]");
        sleep(5);
    }
    exit(0);
}
