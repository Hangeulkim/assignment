import java.util.Scanner;

class Person{
	String name;
	
	Person(String name){
		this.name = name;
	}
	
	public boolean game() {
		int a=(int)(Math.random()*3+1),b=(int)(Math.random()*3+1),c=(int)(Math.random()*3+1);
		System.out.print("\t\t"+a+"\t"+b+"\t"+c+"\t");
		if(a==b && b==c) return true;
		else return false;
	}
}

public class ����_10 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("1��° ���� �̸�>>");
		String first_name=sc.nextLine();
		Person first = new Person(first_name);
		System.out.print("2��° ���� �̸�>>");
		String second_name=sc.nextLine();
		Person second = new Person(second_name);
		String stop;
		while(true) {
			System.out.print("["+first.name+"]<Enter>");
			stop=sc.nextLine();
			if(first.game()) {
				System.out.println(first.name+"���� �̰���ϴ�!");
				break;
			}
			else {
				System.out.println("�ƽ�����!");
			}
			System.out.print("["+second.name+"]<Enter>");
			stop=sc.nextLine();
			if(second.game()) {
				System.out.print(second.name+"���� �̰���ϴ�!");
				break;
			}
			else {
				System.out.println("�ƽ�����!");
			}
		}
		sc.close();
	}
}
