import java.util.Scanner;

class Person{
	String name;
	
	Person(){
		this.name="";
	}
	
	Person(String name){
		this.name = name;
	}
	
	public boolean game() {
		int a=(int)(Math.random()*3+1),b=(int)(Math.random()*3+1),c=(int)(Math.random()*3+1);
		System.out.print("\t\t"+a+"\t"+b+"\t"+c+"\t");
		if(a==b && b==c) return true;
		else return false;
	}
}

public class ����_12 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("�׺��� ���ӿ� ������ ���� ����>>");
		int num=sc.nextInt();
		Person[] p = new Person[num];
		String name=sc.nextLine();
		for(int i=0;i<p.length;i++) {
			System.out.print(i+1+"��° ���� �̸�>>");
			name=sc.nextLine();
			p[i] = new Person(name);
		}
		boolean sflag=false;
		String stop;
		while(true) {
			for(int i=0;i<p.length;i++) {
				System.out.print("["+p[i].name+"]:<Enter>");
				stop=sc.nextLine();
				if(p[i].game()) {
					sflag=true;
					System.out.println(p[i].name+"���� �̰���ϴ�!");
					break;
				}
				else System.out.println("�ƽ�����!");
			}
			if(sflag) break;
		}
		sc.close();
	}
}
